﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment2PartA
{
    public partial class ManageCustomer : Form
    {
        public static ManageCustomer instance;
        public ListBox lb1;
        public ManageCustomer()
        {
            InitializeComponent();
            instance = this;
            lb1 = new ListBox();
        }

        public void ManageAccount()
        {

        }
        private void btnManage_Click(object sender, EventArgs e, EventHandler fm2btnManage_Click)
        {
            ManageAccount();
            ManageCustomer fm2 = new ManageCustomer();
            fm2.Show();
            fm2.btnManage.Click += new EventHandler(fm2btnManage_Click);

        }
    }
}
