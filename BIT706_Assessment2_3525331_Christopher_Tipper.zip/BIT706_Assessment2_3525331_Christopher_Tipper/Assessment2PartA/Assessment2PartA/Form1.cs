﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace Assessment2PartA
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        List<Customer> AllCustomers = new List<Customer>();
        Adding a = new Adding();
        Editing g = new Editing();
        Finding f = new Finding();
        Deleting d = new Deleting();
        

        public Form1()
        {
            InitializeComponent();
            ReadTextFile();
            AddingCustomers();
            FindingCustomers();
            EditingCustomers();
            DeletingCustomers();
            instance = this;
        }

        public void AddingCustomers()
        {
            listBox1.Items.Clear();
            foreach (Customer c in a.addingCustomers)
            {
                listBox1.Items.Add(c.Customers);
            }
            listBox1.SelectedIndex = 1;
        }

        public void FindingCustomers()
        {
            listBox1.Items.Clear();
            foreach (Customer c in f.findingCustomers)
            {
                listBox1.Items.Add(c.Customers);
            }
            listBox1.SelectedIndex = 1;
        }

        public void EditingCustomers()
        {
            listBox1.Items.Clear();
            foreach (Customer c in g.editingCustomers)
            {
                listBox1.Items.Equals(c.Customers);
            }
            listBox1.SelectedIndex = 1;
        }

        public void DeletingCustomers()
        {
            listBox1.Items.Clear();
            foreach (Customer c in d.deletingCustomers)
            {
                listBox1.Items.Remove(c.Customers);
            }
            listBox1.SelectedIndex = 1;
        }

        private void btnAdding_Click(object sender, EventArgs e)
        {
            Customer c = AllCustomers[listBox1.SelectedIndex];
            a.AddCustomer(c);
            AddingCustomers();
        }
        private void btnFinding_Click(object sender, EventArgs e)
        {
            Customer c = AllCustomers[listBox1.SelectedIndex];
            f.FindCustomer(c);
        }
        private void btnEditing_Click(object sender, EventArgs e)
        {
            Customer c = AllCustomers[listBox1.SelectedIndex];
            g.EditCustomer(c);
            EditingCustomers();
        }
        private void btnDeleting_Click(object sender, EventArgs e)
        {
            Customer c = AllCustomers[listBox1.SelectedIndex];
            d.DeleteCustomer(c);
            DeletingCustomers();
        }

        public void ReadTextFile()
        {
            Customer c = null;
            string[] strArray;

            //open file
            var myfile = new StreamReader("../../data.txt");

            while (!myfile.EndOfStream)
            {
                strArray = myfile.ReadLine().Split(',');

                if (strArray[0] == "Add Customer") { c = new AddingCustomer(strArray[1], Convert.ToInt32(strArray[2])); }
                if (strArray[0] == "Find Customer") { c = new EditingCustomer(strArray[1], Convert.ToInt32(strArray[2])); }
                if (strArray[0] == "Edit Customer") { c = new FindingCustomer(strArray[1], Convert.ToInt32(strArray[2])); }
                if (strArray[0] == "Delete Customer") { c = new DeletingCustomer(strArray[1], Convert.ToInt32(strArray[2])); }

                if (c != null)
                {

                    AllCustomers.Add(c);
                }
                else
                {
                    AllCustomers = null;
                }

            }
            myfile.Close();
        }

    }
}
