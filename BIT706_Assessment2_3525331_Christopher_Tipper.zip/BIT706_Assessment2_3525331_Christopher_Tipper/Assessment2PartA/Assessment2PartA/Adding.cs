﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment2PartA
{
    public class Adding
    {
        private string addCustomer;
        public List<Customer> addingCustomers = new List<Customer>();
        public Adding(string addCustomer)
        {
            Name = addCustomer;
        }
        public Adding() { }

        public string Name { get => addCustomer; set => addCustomer = value; }

        public void AddCustomer(Customer c)
        {
            if (addingCustomers.Contains(c))
            {
                throw new Exception("Customer already exists");
            }
            else
            {
                addingCustomers.Add(c);
            }
        }

        public int NumCustomers()
        {
            return addingCustomers.Count;
        }
        public bool addaCustomer(Customer c)
        {
            if (addingCustomers.Contains(c))
            { return true; }
            else
            { return false; }
        }
    }
}
