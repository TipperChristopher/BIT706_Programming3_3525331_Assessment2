using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Bankproject
{
    public partial class Form1 : Form
    {

        private List<Accounts> AllAccs = new List<Accounts>();
        Accounts a;

        public Form1()
        {
            InitializeComponent();
            DisplayAccounts();
            Everydayaccount();
            Investmentaccount();
            Omniaccount();
            
        }
        public void DisplayAccounts()
        {
            Everyday d = new Everyday("");
            Investment i = new Investment(""); 
            Omni o = new Omni(""); 
            
        }

        public void Everydayaccount()
        {
            Everyday d = new Everyday("");
        }

        public void Investmentaccount()
        {
            Investment i = new Investment("");
        }

        public void Omniaccount()
        {
            Omni o = new Omni("");
        }


        private void btnEveryday_Click(object sender, EventArgs e)
        {
            DisplayAccounts();
            Everydayaccount();
            Everyday d = new Everyday("");
            listBox1.Items.Add(d);
        }

        private void btnInvestment_Click(object sender, EventArgs e)
        {
            DisplayAccounts();
            Investmentaccount();
            Investment i = new Investment("");
            listBox1.Items.Add(i);
        }

        private void btnOmni_Click(object sender, EventArgs e)
        {
            DisplayAccounts();
            Omniaccount();
            Omni o = new Omni("");
            listBox1.Items.Add(o);

        }

        private void ViewAccount(object sender, EventArgs e)
        {
            DisplayAccounts();
            Accounts a;
        }

        private void btnaccountDetails_Click(object sender, EventArgs e)
        {
            DisplayAccounts();
            Accounts a;
        }
        private void btnwithdrawMoney_Click(object sender, EventArgs e)
        {
            DisplayAccounts();
            Accounts a;
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            DisplayAccounts();
            Accounts a;
        }

        private void ReadTextFile()
        {

            Accounts a = null;
            string[] strArray;

            //open file
            var myfile = new StreamReader("../../data.txt");

            while (!myfile.EndOfStream)
            {
                strArray = myfile.ReadLine().Split(',');

                if (strArray[0] == "A") { a = new Everyday(strArray[1], Convert.ToInt32(strArray[2])); }
                if (strArray[0] == "B") { a = new Investment(strArray[1], Convert.ToInt32(strArray[2])); }
                if (strArray[0] == "C") { a = new Omni(strArray[1], Convert.ToInt32(strArray[2])); }
                if (a != null)
                {

                    AllAccs.Add(a);
                }

            }
            myfile.Close();

        }

    }
}