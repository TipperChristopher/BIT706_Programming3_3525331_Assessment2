﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Bankproject
{
    public class InvestmentAcc
    {
        InvestmentAcc a = new InvestmentAcc("");
        Investment o;

        private string investmentAccount;
        public List<Accounts> investmentCustomers = new List<Accounts>();

        public string Omni { get => investmentAccount; set => investmentAccount = value; }
        public InvestmentAcc(string omniAccount)
        {
            Name = omniAccount;
        }
        public InvestmentAcc() { }

        public string Name { get => investmentAccount; set => investmentAccount = value; }

        public void AddCustomer(Accounts a)
        {
            if (a == null)
            {
                throw new AccountAlreadyExistsException(o.Account + " Account already existing"); ;
            }
            investmentCustomers.Add(a);

        }
        public void RemoveCustomer(Accounts a)
        {
            if (a == null)
            {
                throw new AccountAlreadyExistsException(o.Account + " Account already deleted");
            }
            investmentCustomers.Remove(a);
        }
        public void FindCustomer(Accounts a)
        {
            if (a == null)
            {
                investmentCustomers.Remove(o);

            }
            else
            {
                throw new AccountNotCreatedExpection(o.Account + " Account not created");
            }
        }

    }
}
