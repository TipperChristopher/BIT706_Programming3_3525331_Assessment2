﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Bankproject
{
    public class OmniAcc
    {
        OmniAcc a = new OmniAcc("");
        Omni o;
       
        private string omniAccount;
        public List<Accounts> omniCustomers = new List<Accounts>();

        public string Omni { get => omniAccount; set => omniAccount = value; }
        public OmniAcc(string omniAccount) 
        {
            Name = omniAccount;
        }
        public OmniAcc() { }

        public string Name { get => omniAccount; set => omniAccount = value; }

        public void AddCustomer(Accounts a)
        {
            if (a == null)
            {
                throw new AccountAlreadyExistsException(o.Account + " Account already existing"); ;
            }
            omniCustomers.Add(a);

        }
        public void RemoveCustomer(Accounts a) 
        {
            if (a == null)
            {
                throw new AccountAlreadyExistsException(o.Account + " Account already deleted");
            }
            omniCustomers.Remove(a);
        }

        public void FindCustomer(Accounts a)
        { 
            if (a == null)
            {
                omniCustomers.Remove(o);
                
            }
            else
            {
                throw new AccountNotCreatedExpection(o.Account + " Account not created");
            }
        }

    }
}
