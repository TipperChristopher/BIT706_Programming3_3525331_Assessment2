﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Bankproject
{
    public class AccountNotCreatedExpection : Exception
    {
        public AccountNotCreatedExpection()
        {

        }

        public AccountNotCreatedExpection(string message) : base(message)
        {

        }

        public AccountNotCreatedExpection(string message, Exception innerException) : base(message, innerException)
        {

        }

        protected AccountNotCreatedExpection(SerializationInfo info, StreamingContext context) : base(info, context)
        {

        }
    }
}
