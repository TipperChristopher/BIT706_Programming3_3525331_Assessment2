﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Bankproject
{
    public class EverydayAcc
    {
        EverydayAcc a = new EverydayAcc("");
        Everyday o;

        private string everydayAccount;
        public List<Accounts> everydayCustomers = new List<Accounts>();

        public string Omni { get => everydayAccount; set => everydayAccount = value; }
        public EverydayAcc(string omniAccount)
        {
            Name = omniAccount;
        }
        public EverydayAcc() { }

        public string Name { get => everydayAccount; set => everydayAccount = value; }

        public void AddCustomer(Accounts a)
        {
            if (a == null)
            {
                throw new AccountAlreadyExistsException(o.Account + " Account already existing"); ;
            }
            everydayCustomers.Add(a);

        }
        public void RemoveCustomer(Accounts a)
        {
            if (a == null)
            {
                throw new AccountAlreadyExistsException(o.Account + " Account already deleted");
            }
            everydayCustomers.Remove(a);
        }
        public void FindCustomer(Accounts a)
        {
            if (a == null)
            {
                everydayCustomers.Remove(o);

            }
            else
            {
                throw new AccountNotCreatedExpection(o.Account + " Account not created");
            }
        }
    }
}
